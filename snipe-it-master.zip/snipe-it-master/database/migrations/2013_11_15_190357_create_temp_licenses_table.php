<?php

use Illuminate\Database\Migrations\Migration;

class CreateTempLicensesTable extends Migration
{
    /**
     * Run the migrations.
     * 
     * This migration is overwritten by a later migration - 2013_11_25_recreate_licenses_table.php
     *
     * @return void
     */
    public function up()
    {
        
        //

       
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Schema::dropIfExists('licenses');
    }
}
