<?php
return array (
  'app_version' => 'v7.0.13-pre',
  'full_app_version' => 'v7.0.13-pre - build 15360-g4ab478bb9',
  'build_version' => '15360',
  'prerelease_version' => '',
  'hash_version' => 'g4ab478bb9',
  'full_hash' => 'v7.0.13-pre-111-g4ab478bb9',
  'branch' => 'master',
);